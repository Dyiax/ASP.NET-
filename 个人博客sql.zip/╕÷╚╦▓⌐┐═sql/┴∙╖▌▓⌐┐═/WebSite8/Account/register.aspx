﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="register.aspx.cs" Inherits="Account_register" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style1
        {
            text-align: center;
        }
        .style3
        {
            width: 96px;
        }
        .style4
        {
            width: 109px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <p>
        <br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 用户注册：</p>
    <p>
        <table align="center" style="width: 45%; height: 211px;">
            <tr>
                <td class="style4">
                    用户名：</td>
                <td class="style3">
                    <asp:TextBox ID="txtboxUserName" runat="server" style="text-align: center"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td class="style4">
                    密码：</td>
                <td class="style3">
                    <asp:TextBox ID="txtboxPassWord" runat="server"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td class="style4">
                    确认密码：</td>
                <td class="style3">
                    <asp:TextBox ID="txtboxPassWord2" runat="server"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td class="style4">
                    电子邮箱：</td>
                <td class="style3">
                    <asp:TextBox ID="txtboxEmail" runat="server" Width="188px"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td class="style1" colspan="2">
                    <asp:Button ID="btnRegister" runat="server" style="text-align: center" Text="提交" 
                        onclick="Button1_Click" />
                </td>
            </tr>
        </table>
    </p>
    <p>
    </p>
    <p>
    </p>
    <p>
    </p>
    <p>
    </p>
    <p>
    </p>
</asp:Content>

