﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="Login.aspx.cs" Inherits="Account_Login" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
        .style2
        {
            text-align: center;
        }
        .style3
        {
            text-align: left;
        }
        .style4
        {
            text-align: left;
            width: 78px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <p>
        <br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 用户登陆</p>
    <p>
&nbsp;&nbsp;
        <table align="center" style="width: 35%; height: 209px; margin-top: 18px;">
            <tr>
                <td class="style4">
                    用户名</td>
                <td class="style2">
                    <asp:TextBox ID="txtboxUserName" runat="server" Height="49px" Width="237px"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td class="style4">
                    密码</td>
                <td class="style2">
                    <asp:TextBox ID="txtboxPassWord" runat="server" Height="43px" Width="232px" 
                        TextMode="Password"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td class="style4">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    </td>
                <td class="style3">
&nbsp;
                    <asp:Button ID="btnLogin" runat="server" style="text-align: left" Text="登陆" 
                        onclick="Button1_Click" Height="37px" Width="90px" />
                    &nbsp;<asp:Button ID="btnRegister" runat="server" Text="注册" onclick="Button2_Click" 
                        Height="37px" style="margin-left: 0px" Width="92px" />
                </td>
            </tr>
        </table>
    </p>
    <p>
    </p>
    <p>
    </p>
    <p>
    </p>
    <p>
    </p>
    <p>
    </p>
</asp:Content>

