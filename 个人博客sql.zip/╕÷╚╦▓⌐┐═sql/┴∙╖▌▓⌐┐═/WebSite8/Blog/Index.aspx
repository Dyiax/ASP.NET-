﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Blog/BlogMasterPage.master" AutoEventWireup="true" CodeFile="Index.aspx.cs" Inherits="Blog_Index" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
    <p>
    欢迎来到本博客</p>
</asp:Content>

