﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Blog/BlogMasterPage.master" AutoEventWireup="true" CodeFile="SendArticle.aspx.cs" Inherits="Blog_SendArticle" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
    <p>
    <table style="width: 100%; height: 512px;">
        <tr>
            <td style="text-align: center; height: 58px">
                <asp:Label ID="Label1" runat="server" style="font-size: x-large" Text="标题"></asp:Label>
&nbsp;
                <asp:TextBox ID="txtboxTitle" runat="server" Height="34px" Width="595px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="height: 417px; text-align: center">
                <asp:TextBox ID="txtboxContext" runat="server" Height="391px" 
                    style="text-align: left; margin-top: 0px" Width="897px"></asp:TextBox>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                <asp:Button ID="btnSend" runat="server" onclick="btnSend_Click" Text="提交" />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:Button ID="btnBack" runat="server" Text="返回" />
            </td>
        </tr>
    </table>
</p>
<p>
</p>
</asp:Content>

