﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Blog/BlogMasterPage.master" AutoEventWireup="true" CodeFile="ShowArticle.aspx.cs" Inherits="Blog_ShowArticle" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
    <table style="width:100%; height: 360px;">
        <tr>
            <td style="text-align: center; height: 23px;">
                <asp:Label ID="labSubject" runat="server"></asp:Label>
                <br />
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                <asp:Label ID="labAuthor" runat="server"></asp:Label>
            </td>
        </tr>
        <tr>
            <td style="text-align: center">
                <asp:TextBox ID="TxtContent" runat="server" Height="302px" ReadOnly="True" 
                    TextMode="MultiLine" Width="822px"></asp:TextBox>
            </td>
        </tr>
    </table>
</asp:Content>

