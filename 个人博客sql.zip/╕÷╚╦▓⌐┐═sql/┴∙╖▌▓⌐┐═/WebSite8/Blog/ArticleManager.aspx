﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Blog/BlogMasterPage.master" AutoEventWireup="true" CodeFile="ArticleManager.aspx.cs" Inherits="Blog_Article" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
    <p>
        <table style="width: 100%; height: 902px;">
            <tr>
                <td style="text-align: right">
        <asp:Button ID="Button1" runat="server" onclick="Button1_Click" 
            style="text-align: right" Text="发表文章" />
                </td>
            </tr>
            <tr>
                <td>
        <table style="width:70%; height: 870px;">
            <tr>
                <td style="width: 969px; text-align: center;">
                    <asp:DataList ID="DataList1" runat="server" DataKeyField="Subject" 
                        DataSourceID="SqlDataSource1" Width="697px" Height="16px">
                        <ItemTemplate>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <table style="width:100%; height: 170px;">
                                <tr>
                                    <td colspan="2" style="text-align: center">
                                        文章标题：<asp:Label ID="SubjectLabel" runat="server" Text='<%# Eval("Subject") %>' />
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 354px; text-align: center">
                                        &nbsp;</td>
                                    <td style="text-align: center">
                                        &nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="width: 354px; text-align: center">
                                        作者：<asp:Label ID="AuthorLabel" runat="server" Text='<%# Eval("Author") %>' />
                                        &nbsp;&nbsp;&nbsp;
                                    </td>
                                    <td style="text-align: center">
                                        时间<asp:Label ID="TimeLabel" runat="server" Text='<%# Eval("Time") %>' />
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 354px; text-align: center">
                                        &nbsp;</td>
                                    <td style="text-align: center">
                                        <br />
                                        <br />
                                    </td>
                                </tr>
                                <tr>
                                    <td style="text-align: center; width: 354px">
                                        &nbsp;</td>
                                    <td style="text-align: center">
                                        <asp:LinkButton ID="LinkButton6" runat="server" 
                                            PostBackUrl='<%# "ShowArticle.aspx?ArticleID=" + DataBinder.Eval(Container.DataItem,"ArticleID")%>'>查看全文</asp:LinkButton>
                                        <br />
                                    </td>
                                </tr>
                                <tr>
                                    <td style="text-align: right; width: 596px" colspan="2">
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        </td>
                                </tr>
                            </table>
                            <br />
                        </ItemTemplate>
                    </asp:DataList>
                    <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
                        ConnectionString="<%$ ConnectionStrings:db_BlogConnectionString %>" 
                        SelectCommand="SELECT [Author], [Subject], [Time],[Context],[ArticleID] FROM [tb_Article]">
                    </asp:SqlDataSource>
                </td>
            </tr>
        </table>
                </td>
            </tr>
        </table>
    </p>
</asp:Content>

