﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Blog/BlogMasterPage.master" AutoEventWireup="true" CodeFile="UserMassage.aspx.cs" Inherits="Blog_UserMassage" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
    <p style="text-align: left">
        <table style="width:100%;">
            <tr>
                <td colspan="2">
                    <br />
                    用户信息<br />
                </td>
            </tr>
            <tr>
                <td style="width: 214px">
                    用户ID：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </td>
                <td>
                    <asp:TextBox ID="txtboxUserID" runat="server" ReadOnly="True"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td style="width: 214px">
                    用户名：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </td>
                <td>
                    <asp:TextBox ID="txtboxUserName" runat="server"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td style="width: 214px">
                    邮箱：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </td>
                <td>
                    <asp:TextBox ID="txtboxEmail" runat="server"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td style="width: 214px">
                    是否为管理员：&nbsp;&nbsp;
                </td>
                <td>
                    <asp:TextBox ID="txtboxAdmin" runat="server" ReadOnly="True"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: left">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <asp:Button ID="btnSave" runat="server" onclick="btnSave_Click" 
                        style="text-align: center" Text="保存" />
                </td>
            </tr>
        </table>
    </p>
</asp:Content>

