﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Blog/BlogMasterPage.master" AutoEventWireup="true" CodeFile="Massage.aspx.cs" Inherits="Blog_Massage" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
    <p style="text-align: left">
        <table style="width: 100%;">
            <tr>
                <td style="height: 178px">
                    <div style="text-align: left">
                    <asp:Label ID="Label1" runat="server" Text="评论列表："></asp:Label>
                    </div>
                    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
                        DataSourceID="SqlDataSource1" Height="208px" Width="802px">
                        <Columns>
                            <asp:BoundField DataField="Author" HeaderText="Author" 
                                SortExpression="Author" />
                            <asp:BoundField DataField="Subject" HeaderText="Subject" 
                                SortExpression="Subject" />
                            <asp:BoundField DataField="Context" HeaderText="Context" 
                                SortExpression="Context" />
                            <asp:BoundField DataField="Time" HeaderText="Time" SortExpression="Time" />
                        </Columns>
                    </asp:GridView>
                    <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
                        ConnectionString="<%$ ConnectionStrings:db_BlogConnectionString %>" 
                        SelectCommand="SELECT [Author], [Subject], [Context], [Time] FROM [tb_Revert]">
                    </asp:SqlDataSource>
                </td>
            </tr>
            <tr>
                <td style="text-align: left">
                    <br />
                    <asp:Label ID="Label2" runat="server" Text="发表评论："></asp:Label>
                    <br />
                    <br />
                    标题：<asp:TextBox ID="txtboxSubject" runat="server" Height="31px" Width="709px"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td style="text-align: left">
                    <br />
                    内容：<asp:TextBox ID="txtboxContent" runat="server" Height="148px" Width="815px"></asp:TextBox>
                    <br />
                </td>
            </tr>
            <tr>
                <td style="text-align: center">
                    <asp:Button ID="btnSend" runat="server" Text="发表评论" onclick="btnSend_Click" />
                </td>
            </tr>
        </table>
</p>
</asp:Content>

