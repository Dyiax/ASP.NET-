﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Blog/BlogMasterPage.master" AutoEventWireup="true" CodeFile="UserManager.aspx.cs" Inherits="Blog_UserManager" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
    <p style="text-align: left">
        <table style="width: 100%;">
            <tr>
                <td>
                    <asp:SqlDataSource ID="SqlDataSource1" runat="server" 
                        ConnectionString="<%$ ConnectionStrings:db_BlogConnectionString %>" 
                        SelectCommand="SELECT [UserName], [ID], [IsAdmin] FROM [tb_User]" 
                        DeleteCommand="DELETE FROM [tb_User] WHERE [UserName] = @UserName" 
                        InsertCommand="INSERT INTO [tb_User] ([UserName], [ID], [IsAdmin]) VALUES (@UserName, @ID, @IsAdmin)" 
                        UpdateCommand="UPDATE [tb_User] SET [ID] = @ID, [IsAdmin] = @IsAdmin WHERE [UserName] = @UserName">
                        <DeleteParameters>
                            <asp:Parameter Name="UserName" Type="String" />
                        </DeleteParameters>
                        <InsertParameters>
                            <asp:Parameter Name="UserName" Type="String" />
                            <asp:Parameter Name="ID" Type="Int32" />
                            <asp:Parameter Name="IsAdmin" Type="Int32" />
                        </InsertParameters>
                        <UpdateParameters>
                            <asp:Parameter Name="ID" Type="Int32" />
                            <asp:Parameter Name="IsAdmin" Type="Int32" />
                            <asp:Parameter Name="UserName" Type="String" />
                        </UpdateParameters>
                    </asp:SqlDataSource>
                    <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
                        DataKeyNames="UserName" DataSourceID="SqlDataSource1" Width="669px" 
                        >
                        <Columns>
                            <asp:CommandField ShowEditButton="True" />
                            <asp:BoundField DataField="UserName" HeaderText="UserName" ReadOnly="True" 
                                SortExpression="UserName" />
                            <asp:BoundField DataField="ID" HeaderText="ID" SortExpression="ID" />
                            <asp:BoundField DataField="IsAdmin" HeaderText="IsAdmin" 
                                SortExpression="IsAdmin" />
                            <asp:ButtonField ButtonType="Button" CommandName="Delete" Text="删除用户" />
                        </Columns>
                    </asp:GridView>
                    <br />
                </td>
            </tr>
            <tr>
                <td>
                    <br />
                </td>
            </tr>
        </table>
</p>
</asp:Content>

